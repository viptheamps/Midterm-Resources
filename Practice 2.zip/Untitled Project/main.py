# Ask the user to input their name
name = input("Enter your name: ")

# Ask the user to input their age
age = input("Enter your age: ")

# Print out a message using formatted string
print("Hello, {}! You are {} years old.".format(name, age))
