def print_pattern(rows):
    # Upper part of the pattern
    for i in range(rows):
        for j in range(i + 1):
            print("*", end=" ")
        print()

    # Lower part of the pattern
    for i in range(rows - 1, 0, -1):
        for j in range(i):
            print("*", end=" ")
        print()

# Change the number of rows as desired
num_rows = 5
print_pattern(num_rows)
